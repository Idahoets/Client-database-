# Vintage Queen backend - starting scaffold

This is a working starting point, not a finished, tested integration - it hasn't
run against a live Clover account yet (this environment can't make outbound
network calls). The plan is to open this folder in Claude Code, where I can
actually run it, hit real Clover endpoints, and fix whatever the real API
responses don't match.

## What's here

- `src/db.js` - SQLite schema: consignors, items, sync bookkeeping, generated reports
- `src/clover.js` - Clover REST API client (items, orders)
- `src/sync.js` - matches Clover order line items back to consignors by SKU, updates statuses
- `src/reports.js` - the two payout jobs: estate payout (7 days after each estate sale), storefront statement (monthly, payable at 90-day contract end)
- `src/server.js` - small API the portal reads from
- `src/seed.js` - add your real consignors here

## Before we run this for real, in Claude Code, we need to:

1. **Get your Clover API token.** Register as a Clover developer, create a
   private app, install it on your own merchant account - that generates the
   access token. I'll walk through each screen with you when we're there.
2. **Confirm your SKU format.** I guessed `DM-0042` for regular items and
   `hask8 misc` for misc lots based on what you described - we should check a
   few real Clover items together and adjust the parsing in `sync.js` if the
   actual format differs.
3. **Figure out how to tell estate-sale orders apart from storefront orders**
   in Clover. `isEstateSaleOrder()` in `clover.js` is a placeholder - once we
   see a real order from an estate sale (probably tied to a specific device or
   employee login), we can fill that in properly.
4. **Decide how statements actually reach consignors** - email, text, printed,
   posted in the portal only, etc. `reports.js` has a TODO right where that
   hooks in.

## Running it (once .env is filled in)

```bash
npm install
cp .env.example .env   # then fill in your real Clover credentials
npm run sync            # pulls recent Clover orders and updates the database
npm start                # starts the API + the two scheduled report jobs
```
