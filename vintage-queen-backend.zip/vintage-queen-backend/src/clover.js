import 'dotenv/config';

const BASE = process.env.CLOVER_API_BASE;
const MERCHANT_ID = process.env.CLOVER_MERCHANT_ID;
const TOKEN = process.env.CLOVER_ACCESS_TOKEN;

async function cloverGet(path, params = {}) {
  const url = new URL(`${BASE}/v3/merchants/${MERCHANT_ID}${path}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${TOKEN}` }
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Clover API error ${res.status}: ${body}`);
  }
  return res.json();
}

// Pulls all inventory items (used to see SKUs and current price/stock)
export async function getItems() {
  const data = await cloverGet('/items', { expand: 'categories', limit: 1000 });
  return data.elements || [];
}

// Pulls orders modified since a given timestamp (ms), with line items expanded.
// Clover's `filter=modifiedTime>=X` catches new sales without re-scanning everything.
export async function getOrdersSince(sinceMs) {
  const data = await cloverGet('/orders', {
    expand: 'lineItems',
    filter: `modifiedTime>=${sinceMs}`,
    limit: 1000
  });
  return data.elements || [];
}

// Clover order objects don't have a native "which register/location" flag beyond
// device/employee info. If estate sales run on a separate Clover device or
// employee login, that id is what distinguishes an estate-sale order from a
// storefront order - check the `device` or `employee` field on real order
// payloads once you're connected, and adjust this function accordingly.
export function isEstateSaleOrder(order) {
  // PLACEHOLDER - fill in once we see real order payloads in Claude Code.
  // e.g. return order.device?.id === process.env.ESTATE_SALE_DEVICE_ID;
  return false;
}
