import db from './db.js';
import { getOrdersSince, isEstateSaleOrder } from './clover.js';

// Matches SKUs like:
//   "DM-0042"      -> a regular item belonging to consignor DM
//   "hask8 misc"   -> a misc bucket, consignor code embedded, $8 price point
// Adjust these patterns once we see how your team actually formats SKUs in Clover.
const REGULAR_SKU = /^([A-Z]{2,4})-(\d+)$/i;
const MISC_SKU = /^([A-Za-z]+)(\d+)\s*misc$/i;

function parseSku(sku) {
  if (!sku) return null;

  const misc = sku.match(MISC_SKU);
  if (misc) {
    return { code: misc[1].toUpperCase(), price: Number(misc[2]), isMisc: true };
  }

  const regular = sku.match(REGULAR_SKU);
  if (regular) {
    return { code: regular[1].toUpperCase(), itemNumber: regular[2], isMisc: false };
  }

  return null;
}

function getLastSyncTime() {
  const row = db.prepare(`SELECT value FROM sync_state WHERE key = 'last_sync_ms'`).get();
  return row ? Number(row.value) : 0;
}

function setLastSyncTime(ms) {
  db.prepare(`
    INSERT INTO sync_state (key, value) VALUES ('last_sync_ms', ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(String(ms));
}

export async function runSync() {
  const since = getLastSyncTime();
  const orders = await getOrdersSince(since);
  let updated = 0;

  for (const order of orders) {
    const channel = isEstateSaleOrder(order) ? 'estate_sale' : 'storefront';
    const soldStatus = channel === 'estate_sale' ? 'sold_estate' : 'sold_store';
    const soldDate = new Date(order.modifiedTime).toISOString().slice(0, 10);

    for (const line of order.lineItems?.elements || []) {
      const parsed = parseSku(line.item?.code || line.name);
      if (!parsed) continue; // unmatched line items need a manual look

      const existing = db.prepare(`
        SELECT * FROM items WHERE clover_line_item_id = ?
      `).get(line.id);

      if (existing) continue; // already recorded

      if (parsed.isMisc) {
        // Misc lots get grouped by consignor + price point + day - if today's
        // bucket already exists, bump the quantity instead of adding a new row.
        const bucket = db.prepare(`
          SELECT * FROM items
          WHERE consignor_code = ? AND is_misc = 1 AND tag_price = ? AND sold_date = ? AND channel = ?
        `).get(parsed.code, parsed.price, soldDate, channel);

        if (bucket) {
          db.prepare(`UPDATE items SET qty = qty + 1 WHERE id = ?`).run(bucket.id);
        } else {
          db.prepare(`
            INSERT INTO items (consignor_code, clover_order_id, clover_line_item_id, sku, title,
              category, tag_price, qty, is_misc, channel, status, sold_price, sold_date)
            VALUES (?, ?, ?, ?, 'Misc lot', 'Misc', ?, 1, 1, ?, ?, ?, ?)
          `).run(parsed.code, order.id, line.id, line.item?.code, parsed.price, channel, soldStatus, parsed.price, soldDate);
        }
      } else {
        db.prepare(`
          UPDATE items SET status = ?, sold_price = ?, sold_date = ?, clover_order_id = ?, clover_line_item_id = ?
          WHERE consignor_code = ? AND sku = ?
        `).run(soldStatus, line.price / 100, soldDate, order.id, line.id, parsed.code, line.item?.code);
      }
      updated++;
    }
  }

  setLastSyncTime(Date.now());
  console.log(`Sync complete: ${updated} line items processed from ${orders.length} orders.`);
}

// Run directly with `npm run sync`
if (import.meta.url === `file://${process.argv[1]}`) {
  runSync().catch(err => {
    console.error('Sync failed:', err.message);
    process.exit(1);
  });
}
